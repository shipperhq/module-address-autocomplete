<?php
    \Magento\Framework\Component\ComponentRegistrar::register(
        \Magento\Framework\Component\ComponentRegistrar::MODULE,
        'ShipperHQ_AddressAutocomplete',
        __DIR__
    );
